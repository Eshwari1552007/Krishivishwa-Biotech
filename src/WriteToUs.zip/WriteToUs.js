import React, { useEffect, useRef } from "react";
import './WriteToUs.css';

export default function WriteToUs() {
    const sectionRef = useRef(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        observer.unobserve(entry.target);
                    }
                });
            },
            {
                threshold: 0.5,
                rootMargin: "0px 0px -100px 0px"
            }
        );

        if (sectionRef.current) {
            observer.observe(sectionRef.current);
        }
    }, []);

    const handleButtonClick = () => {
        const btn = document.querySelector(".animated-button");
        btn.classList.add("sending");

        setTimeout(() => {
            btn.classList.add("sent");
        }, 1800);

        setTimeout(() => {
            btn.classList.remove("sending", "sent");
        }, 4000);
    };

    return (
        <div className="write-to-us-section">
            <div className="right-to-use-container" ref={sectionRef}>
                <div className="contact-left">
                    <p className="subheading">GET CONNECT WITH US</p>
                    <h1><span className="highlight">Discuss</span> Your<br />Chemical Solution Needs</h1>
                    <p className="description">
                        Reach out to Krishivishwa Biotech for your agricultural solutions. We are ready to assist you with expert guidance and sustainable products.
                    </p>
                    <div className="contact-info">
                        <p><i > <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-open-fill" viewBox="0 0 16 16">
                            <path d="M8.941.435a2 2 0 0 0-1.882 0l-6 3.2A2 2 0 0 0 0 5.4v.314l6.709 3.932L8 8.928l1.291.718L16 5.714V5.4a2 2 0 0 0-1.059-1.765zM16 6.873l-5.693 3.337L16 13.372v-6.5Zm-.059 7.611L8 10.072.059 14.484A2 2 0 0 0 2 16h12a2 2 0 0 0 1.941-1.516M0 13.373l5.693-3.163L0 6.873z" />
                        </svg></i> krishivishwabiotech@gmail.com</p>
                        <p><i > <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                            <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6" />
                        </svg></i> Gat. No.: 227 At. Virgaon,
                            Tal. Akole, Dist. Ahmednagar (MH). Pin. 422605.</p>
                        <p><i ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-fill" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877z" />
                        </svg></i> Mob.: 9960492426  <pre/> Ph.: 02424-261100</p>
                        

                    </div>
                </div>

                <div className="contact-right">
                    <form className="contact-form" onSubmit={(e) => e.preventDefault()}>
                        <div className="input-group">
                            <input type="text" name="name" required />
                            <label>Name</label>
                        </div>

                        <div className="input-group">
                            <input type="email" name="email" required />
                            <label>Email</label>
                        </div>

                        <div className="input-group">
                            <input type="tel" name="phone" required />
                            <label>Phone</label>
                        </div>

                        <div className="input-group">
                            <textarea rows="3" required></textarea>
                            <label>Address</label>
                        </div>

                        <button type="button" className="animated-button" onClick={handleButtonClick}>
                            <span className="btn-wrapper">
                                <span className="btn-text">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                                        <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0M4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5z" />
                                    </svg>
                                    Get a Solution
                                </span>
                                <span className="btn-arrow-line"></span>
                                <span className="btn-check"><i className="fas fa-check"></i></span>
                            </span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
}
